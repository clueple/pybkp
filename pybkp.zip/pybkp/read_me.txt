zip file location:

#all the csv files to build the bookkeeping system

https://github.com/clueple/pybkp/blob/main/py_acct.zip